# Project Quirkle - Integration 1.2

Team Members: Seifeldin, Sakis and Nathan 
